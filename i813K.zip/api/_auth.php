<?php
session_start();
function is_admin(){ return isset($_SESSION['user']) && $_SESSION['user_role']==='admin'; }
function is_sub(){ return isset($_SESSION['user']) && $_SESSION['user_role']==='sub'; }
function require_admin(){ if(!is_admin()){ header('Location: /admin/login.php'); exit; } }
function require_sub(){ if(!(is_sub()||is_admin())){ header('Location: /login.php'); exit; } }
