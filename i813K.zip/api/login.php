<?php
require_once __DIR__.'/_auth.php';
$usersPath = __DIR__.'/../data/users.json';
$users = json_decode(file_get_contents($usersPath), true) ?: [];
$u = trim($_POST['username'] ?? ''); $p = $_POST['password'] ?? '';
$hash = hash('sha256',$p);
if(isset($users[$u]) && $users[$u]['password_hash']===$hash){
  $_SESSION['user']=$u;
  $_SESSION['user_role']=($users[$u]['role']==='admin'?'admin':'sub');
  header('Location: /index.php'); exit;
}
header('Location: /login.php?err=1');
