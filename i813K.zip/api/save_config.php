<?php
require_once __DIR__.'/_auth.php'; require_admin();
$cfgPath = __DIR__.'/../config/config.json';
if($_SERVER['REQUEST_METHOD']!=='POST'){ http_response_code(405); exit; }
$json = $_POST['json'] ?? '';
json_decode($json);
if(json_last_error()!==JSON_ERROR_NONE){ http_response_code(400); echo 'JSON不合法'; exit; }
file_put_contents($cfgPath, $json);
echo 'OK';
