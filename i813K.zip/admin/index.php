
<?php require_once __DIR__.'/../api/_auth.php'; require_admin(); ?>
<!doctype html><html lang="zh"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>后台首页</title>
<style>
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,PingFang SC,Microsoft Yahei, sans-serif;margin:0;background:#f6f7fb;color:#0f172a}
.header{background:linear-gradient(90deg,#2563eb,#60a5fa);color:#fff;padding:14px 18px;font-weight:700;box-shadow:0 6px 16px rgba(37,99,235,.25)}
.wrap{max-width:1200px;margin:20px auto;padding:0 18px}
.card{background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:16px;box-shadow:0 10px 26px rgba(2,6,23,.06);margin-bottom:16px}
.btn{display:inline-block;background:linear-gradient(90deg,#2563eb,#60a5fa);color:#fff;border:0;border-radius:10px;padding:10px 14px;text-decoration:none}
.btn:hover{filter:brightness(1.05)}
table{border-collapse:separate;border-spacing:0;width:100%;overflow:hidden;border-radius:12px}
th{background:#f1f5f9}
td,th{border:1px solid #e5e7eb;padding:8px 10px;text-align:left}
input,select{padding:10px;border:1px solid #cbd5e1;border-radius:10px}
button{padding:10px 12px;border-radius:10px;border:0;background:#2563eb;color:#fff}
button:hover{filter:brightness(1.05)}
a.link{color:#2563eb;text-decoration:none}
a.link:hover{text-decoration:underline}
.notice{margin:8px 0;padding:10px 12px;border-left:4px solid #10b981;background:#ecfdf5}
.err{margin:8px 0;padding:10px 12px;border-left:4px solid #ef4444;background:#fef2f2}
</style></head><body>
<div class="header">后台管理</div>
<div class="wrap">
  <div class="card">
    <a class="btn" href="/admin/params.php">参数管理（中文类目）</a>
    <a class="btn" href="/admin/users.php" style="margin-left:12px">子账号管理</a>
    <a class="btn" href="/api/logout.php" style="margin-left:12px">退出登录</a>
  </div>
</div>
</body></html>
