<?php
require_once __DIR__.'/../api/_auth.php'; 
require_admin();

$cfgPath = __DIR__.'/../config/config.json';
$cfg = json_decode(file_get_contents($cfgPath), true);

$act = $_POST['act'] ?? '';
$error = '';
$success = '';
$current_tab = $_GET['tab'] ?? 'shipping';
$scroll_to = $_GET['scroll'] ?? '';

// 处理表单提交
if($act) {
    $admin_pwd = $_POST['admin_pwd'] ?? '';
    
    // 密码验证（实际应用中应使用更安全的方式）
    if($admin_pwd !== "admin123") {
        $error = "管理员密码不正确";
    } else {
        // 编辑操作
        if($act==='prov_edit'){ 
            $k=trim($_POST['k']); $new_k=trim($_POST['new_k']); $v=floatval($_POST['v']); 
            if($k !== $new_k) unset($cfg['province_rates'][$k]);
            $cfg['province_rates'][$new_k] = $v;
            $success = "地区运费更新成功";
        }
        if($act==='gx_t_edit'){ 
            $k=trim($_POST['k']); $new_k=trim($_POST['new_k']); $v=floatval($_POST['v']); 
            if($k !== $new_k) unset($cfg['galvanized']['thickness_density'][$k]);
            $cfg['galvanized']['thickness_density'][$new_k] = $v;
            $success = "厚度密度更新成功";
        }
        if($act==='gx_p_edit'){ 
            $k=trim($_POST['k']); $new_k=trim($_POST['new_k']); $v=floatval($_POST['v']); 
            if($k !== $new_k) unset($cfg['galvanized']['paint_rates_per_kg'][$k]);
            $cfg['galvanized']['paint_rates_per_kg'][$new_k] = $v;
            $success = "烤漆单价更新成功";
        }
        if($act==='gx_s_edit'){ 
            $k=trim($_POST['k']); $new_k=trim($_POST['new_k']); $v=floatval($_POST['v']); 
            if($k !== $new_k) unset($cfg['galvanized']['style_surcharge_per_kg'][$k]);
            $cfg['galvanized']['style_surcharge_per_kg'][$new_k] = $v;
            $success = "款式溢价更新成功";
        }
        if($act==='ss_p_edit'){ 
            $k=trim($_POST['k']); $new_k=trim($_POST['new_k']); $v=floatval($_POST['v']); 
            if($k !== $new_k) unset($cfg['stainless']['paint_rates_per_kg'][$k]);
            $cfg['stainless']['paint_rates_per_kg'][$new_k] = $v;
            $success = "烤漆设置更新成功";
        }
        if($act==='ss_np_edit'){ 
            $k=trim($_POST['k']); $new_k=trim($_POST['new_k']); $v=floatval($_POST['v']); 
            if($k !== $new_k) unset($cfg['stainless']['non_paint_per_m2'][$k]);
            $cfg['stainless']['non_paint_per_m2'][$new_k] = $v;
            $success = "非烤漆设置更新成功";
        }
        if($act==='ss_s_edit'){ 
            $k=trim($_POST['k']); $new_k=trim($_POST['new_k']); $v=floatval($_POST['v']); 
            if($k !== $new_k) unset($cfg['stainless']['style_surcharge_per_kg'][$k]);
            $cfg['stainless']['style_surcharge_per_kg'][$new_k] = $v;
            $success = "款式溢价更新成功";
        }
        if($act==='ss_t_edit'){ 
            $g=trim($_POST['g']); $t=trim($_POST['t']); $new_t=trim($_POST['new_t']); 
            $p=floatval($_POST['p']); $w=floatval($_POST['w']);
            if($t !== $new_t) unset($cfg['stainless']['grades'][$g][$t]);
            $cfg['stainless']['grades'][$g][$new_t] = ['price_per_m2'=>$p,'weight_per_m2'=>$w];
            $success = "不锈钢厚度参数更新成功";
            $scroll_to = 'grade_'.md5($g); // 设置滚动位置
        }
        
        // 添加操作
        if($act==='prov_add'){ 
            $k=trim($_POST['k']); $v=floatval($_POST['v']); 
            $cfg['province_rates'][$k]=$v; 
            $success = "地区运费添加成功";
        }
        if($act==='gx_t_add'){ 
            $k=trim($_POST['k']); $v=floatval($_POST['v']); 
            $cfg['galvanized']['thickness_density'][$k]=$v; 
            $success = "厚度密度添加成功";
        }
        if($act==='gx_p_add'){ 
            $k=trim($_POST['k']); $v=floatval($_POST['v']); 
            $cfg['galvanized']['paint_rates_per_kg'][$k]=$v; 
            $success = "烤漆单价添加成功";
        }
        if($act==='gx_s_add'){ 
            $k=trim($_POST['k']); $v=floatval($_POST['v']); 
            $cfg['galvanized']['style_surcharge_per_kg'][$k]=$v; 
            $success = "款式溢价添加成功";
        }
        if($act==='ss_grade_add'){ 
            $g=trim($_POST['g']); 
            if(!isset($cfg['stainless']['grades'][$g])) $cfg['stainless']['grades'][$g]=[]; 
            $success = "新材质创建成功";
            $scroll_to = 'grade_'.md5($g); // 设置滚动位置
        }
        if($act==='ss_t_add'){
            $g=trim($_POST['g']); $t=trim($_POST['t']); $p=floatval($_POST['p']); $w=floatval($_POST['w']);
            if(!isset($cfg['stainless']['grades'][$g])) $cfg['stainless']['grades'][$g]=[];
            $cfg['stainless']['grades'][$g][$t] = ['price_per_m2'=>$p,'weight_per_m2'=>$w];
            $success = "不锈钢厚度添加成功";
            $scroll_to = 'grade_'.md5($g); // 设置滚动位置
        }
        if($act==='ss_p_add'){ 
            $k=trim($_POST['k']); $v=floatval($_POST['v']); 
            $cfg['stainless']['paint_rates_per_kg'][$k]=$v; 
            $success = "烤漆设置添加成功";
        }
        if($act==='ss_np_add'){ 
            $k=trim($_POST['k']); $v=floatval($_POST['v']); 
            $cfg['stainless']['non_paint_per_m2'][$k]=$v; 
            $success = "非烤漆设置添加成功";
        }
        if($act==='ss_s_add'){ 
            $k=trim($_POST['k']); $v=floatval($_POST['v']); 
            $cfg['stainless']['style_surcharge_per_kg'][$k]=$v; 
            $success = "款式溢价添加成功";
        }
        if($act==='profit_add'){ 
            $v=floatval($_POST['v']); 
            $cfg['ui']['profit_rates'][]=$v; 
            $cfg['ui']['profit_rates']=array_values(array_unique($cfg['ui']['profit_rates'])); 
            sort($cfg['ui']['profit_rates']); 
            $success = "利润率添加成功";
        }
        if($act==='profit_del'){ 
            $v=floatval($_POST['v']); 
            $cfg['ui']['profit_rates']=array_values(array_filter($cfg['ui']['profit_rates'], fn($x)=>$x!=$v)); 
            $success = "利润率删除成功";
        }
        
        // 删除操作
        if($act==='prov_del'){ 
            $k=trim($_POST['k']); 
            unset($cfg['province_rates'][$k]); 
            $success = "地区运费删除成功";
        }
        if($act==='gx_t_del'){ 
            $k=trim($_POST['k']); 
            unset($cfg['galvanized']['thickness_density'][$k]); 
            $success = "厚度密度删除成功";
        }
        if($act==='gx_p_del'){ 
            $k=trim($_POST['k']); 
            unset($cfg['galvanized']['paint_rates_per_kg'][$k]); 
            $success = "烤漆单价删除成功";
        }
        if($act==='gx_s_del'){ 
            $k=trim($_POST['k']); 
            unset($cfg['galvanized']['style_surcharge_per_kg'][$k]); 
            $success = "款式溢价删除成功";
        }
        if($act==='ss_grade_del'){ 
            $g=trim($_POST['g']); 
            unset($cfg['stainless']['grades'][$g]); 
            $success = "不锈钢材质删除成功";
        }
        if($act==='ss_t_del'){ 
            $g=trim($_POST['g']); $t=trim($_POST['t']); 
            unset($cfg['stainless']['grades'][$g][$t]); 
            $success = "不锈钢厚度删除成功";
            $scroll_to = 'grade_'.md5($g); // 设置滚动位置
        }
        if($act==='ss_p_del'){ 
            $k=trim($_POST['k']); 
            unset($cfg['stainless']['paint_rates_per_kg'][$k]); 
            $success = "烤漆设置删除成功";
        }
        if($act==='ss_np_del'){ 
            $k=trim($_POST['k']); 
            unset($cfg['stainless']['non_paint_per_m2'][$k]); 
            $success = "非烤漆设置删除成功";
        }
        if($act==='ss_s_del'){ 
            $k=trim($_POST['k']); 
            unset($cfg['stainless']['style_surcharge_per_kg'][$k]); 
            $success = "款式溢价删除成功";
        }
        
        // 保存配置
        file_put_contents($cfgPath, json_encode($cfg,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
        
        // 重定向到当前标签页和滚动位置
        $redirect_url = "params.php?tab=$current_tab";
        if ($scroll_to) {
            $redirect_url .= "&scroll=$scroll_to";
        }
        header("Location: $redirect_url");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>参数管理系统</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #2563eb;
            --primary-light: #60a5fa;
            --primary-dark: #1d4ed8;
            --secondary: #475569;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --light: #f8fafc;
            --dark: #0f172a;
            --border: #e2e8f0;
            --shadow: rgba(15, 23, 42, 0.1);
            --card-bg: #ffffff;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, 
                        PingFang SC, Microsoft Yahei, sans-serif;
            background: linear-gradient(135deg, #f0f9ff, #e0f2fe);
            color: var(--dark);
            line-height: 1.6;
            padding: 20px;
            min-height: 100vh;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .header {
            background: linear-gradient(90deg, var(--primary), var(--primary-light));
            color: white;
            padding: 20px 30px;
            margin-bottom: 30px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(37, 99, 235, 0.3);
            position: relative;
            overflow: hidden;
        }

        .header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 70%);
            transform: rotate(30deg);
        }

        .header h1 {
            font-size: 2.2rem;
            font-weight: 800;
            margin-bottom: 10px;
            position: relative;
        }

        .header p {
            opacity: 0.9;
            margin-bottom: 15px;
            position: relative;
            font-size: 1.1rem;
        }

        .nav-links {
            display: flex;
            gap: 15px;
            margin-top: 10px;
            position: relative;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.15);
            transition: all 0.3s;
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-links a:hover {
            background: rgba(255, 255, 255, 0.25);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .tabs {
            display: flex;
            gap: 8px;
            margin-bottom: 25px;
            background: white;
            border-radius: 16px;
            padding: 12px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.08);
            flex-wrap: wrap;
        }

        .tab {
            padding: 14px 28px;
            background: #f1f5f9;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s;
            font-weight: 600;
            font-size: 1.05rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .tab i {
            font-size: 1.2rem;
        }

        .tab.active {
            background: linear-gradient(90deg, var(--primary), var(--primary-light));
            color: white;
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
        }

        .tab-content {
            display: none;
            animation: fadeIn 0.5s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .tab-content.active {
            display: block;
        }

        .card {
            background: var(--card-bg);
            border-radius: 16px;
            box-shadow: 0 8px 25px var(--shadow);
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid rgba(255, 255, 255, 0.5);
            backdrop-filter: blur(10px);
            position: relative;
            overflow: hidden;
        }

        .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--primary-light));
        }

        .card-title {
            font-size: 1.5rem;
            color: var(--primary);
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-title .badge {
            background: var(--primary-light);
            color: white;
            padding: 6px 14px;
            border-radius: 24px;
            font-size: 1rem;
            font-weight: 600;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-row {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
            align-items: center;
            flex-wrap: wrap;
        }

        .form-row input, .form-row select {
            flex: 1;
            min-width: 200px;
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: var(--secondary);
            font-size: 1.05rem;
        }

        input, select, button, .btn {
            padding: 14px 18px;
            border: 1px solid var(--border);
            border-radius: 10px;
            font-size: 1.05rem;
            transition: all 0.3s;
            outline: none;
        }

        input:focus, select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.15);
        }

        button, .btn {
            background: linear-gradient(90deg, var(--primary), var(--primary-light));
            color: white;
            border: none;
            cursor: pointer;
            font-weight: 600;
            padding: 14px 24px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            text-decoration: none;
        }

        button:hover, .btn:hover {
            background: linear-gradient(90deg, var(--primary-dark), var(--primary));
            transform: translateY(-3px);
            box-shadow: 0 6px 12px rgba(37, 99, 235, 0.25);
        }

        .btn-sm {
            padding: 10px 16px;
            font-size: 0.95rem;
        }

        .btn-edit {
            background: linear-gradient(90deg, var(--warning), #fbbf24);
        }

        .btn-edit:hover {
            background: linear-gradient(90deg, #d97706, var(--warning));
        }

        .btn-danger {
            background: linear-gradient(90deg, var(--danger), #f87171);
        }

        .btn-danger:hover {
            background: linear-gradient(90deg, #dc2626, var(--danger));
        }

        .btn-success {
            background: linear-gradient(90deg, var(--success), #34d399);
        }

        .btn-success:hover {
            background: linear-gradient(90deg, #059669, var(--success));
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 25px 0;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }

        th {
            background: linear-gradient(to bottom, #f1f5f9, #e2e8f0);
            padding: 16px 20px;
            text-align: left;
            font-weight: 700;
            color: var(--secondary);
            border-bottom: 2px solid var(--border);
        }

        td {
            padding: 14px 20px;
            border-bottom: 1px solid var(--border);
        }

        tr:last-child td {
            border-bottom: none;
        }

        tr:hover {
            background-color: #f8fafc;
        }

        .action-cell {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .section-title {
            font-size: 1.25rem;
            margin: 28px 0 15px;
            padding-left: 12px;
            border-left: 4px solid var(--primary);
            color: var(--secondary);
            font-weight: 600;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .notice {
            background-color: #ecfdf5;
            border-left: 4px solid var(--success);
            padding: 16px 20px;
            margin: 20px 0;
            border-radius: 0 12px 12px 0;
            font-size: 1.05rem;
        }

        .warning {
            background-color: #fffbeb;
            border-left: 4px solid var(--warning);
            padding: 16px 20px;
            margin: 20px 0;
            border-radius: 0 12px 12px 0;
            font-size: 1.05rem;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 28px;
        }

        .edit-form {
            background: #f8fafc;
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 20px;
            margin-top: 20px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        }

        .password-section {
            background: #f1f5f9;
            border-radius: 12px;
            padding: 20px;
            margin: 20px 0;
            border: 1px dashed var(--primary);
        }

        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            margin: 20px 0;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .alert-success {
            background-color: #d1fae5;
            color: #065f46;
            border-left: 4px solid var(--success);
        }

        .alert-error {
            background-color: #fee2e2;
            color: #b91c1c;
            border-left: 4px solid var(--danger);
        }

        .icon {
            font-size: 1.5rem;
        }

        @media (max-width: 768px) {
            .form-row {
                flex-direction: column;
                gap: 12px;
                align-items: stretch;
            }
            
            .action-cell {
                flex-direction: column;
                gap: 8px;
            }
            
            .nav-links {
                flex-direction: column;
                gap: 10px;
            }
            
            .tabs {
                flex-direction: column;
            }
            
            .tab {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1><i class="fas fa-sliders-h"></i> 参数管理系统</h1>
        <p>管理运费、材料参数和利润率设置</p>
        <div class="nav-links">
            <a href="/admin/"><i class="fas fa-home"></i> 返回后台首页</a>
            <a href="/api/logout.php"><i class="fas fa-sign-out-alt"></i> 退出登录</a>
        </div>
    </div>
    
    <?php if($success): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle icon"></i>
            <div><?php echo $success; ?></div>
        </div>
    <?php endif; ?>
    
    <?php if($error): ?>
        <div class="alert alert-error">
            <i class="fas fa-exclamation-circle icon"></i>
            <div><?php echo $error; ?></div>
        </div>
    <?php endif; ?>
    
    <div class="password-section">
        <h3><i class="fas fa-lock"></i> 管理员验证</h3>
        <p>所有操作都需要输入管理员密码</p>
        <form method="post" class="form-group">
            <div class="form-row">
                <input type="password" name="admin_pwd" placeholder="请输入管理员密码" required style="flex: 1;">
                <button type="submit" name="act" value="verify"><i class="fas fa-shield-alt"></i> 验证密码</button>
            </div>
        </form>
    </div>
    
    <div class="tabs">
        <div class="tab <?php echo $current_tab == 'shipping' ? 'active' : ''; ?>" data-tab="shipping">
            <i class="fas fa-truck"></i> 运费管理
        </div>
        <div class="tab <?php echo $current_tab == 'galvanized' ? 'active' : ''; ?>" data-tab="galvanized">
            <i class="fas fa-industry"></i> 镀锌钢参数
        </div>
        <div class="tab <?php echo $current_tab == 'stainless' ? 'active' : ''; ?>" data-tab="stainless">
            <i class="fas fa-hard-hat"></i> 不锈钢参数
        </div>
        <div class="tab <?php echo $current_tab == 'profit' ? 'active' : ''; ?>" data-tab="profit">
            <i class="fas fa-chart-line"></i> 利润率设置
        </div>
    </div>
    
    <!-- 运费管理 -->
    <div class="tab-content <?php echo $current_tab == 'shipping' ? 'active' : ''; ?>" id="shipping">
        <div class="card">
            <div class="card-title">
                <span><i class="fas fa-map-marked-alt"></i> 地区运费设置</span>
                <span class="badge">元/方</span>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>地区</th>
                        <th>单价</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($cfg['province_rates'] as $k=>$v): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($k); ?></td>
                        <td><?php echo $v; ?></td>
                        <td class="action-cell">
                            <button class="btn-sm btn-edit" onclick="showEditForm('prov', '<?php echo htmlspecialchars($k); ?>', '<?php echo $v; ?>')">
                                <i class="fas fa-edit"></i> 编辑
                            </button>
                            <form method="post" style="display:inline">
                                <input type="hidden" name="act" value="prov_del">
                                <input type="hidden" name="k" value="<?php echo htmlspecialchars($k); ?>">
                                <input type="hidden" name="admin_pwd" value="admin123">
                                <input type="hidden" name="tab" value="shipping">
                                <button type="submit" class="btn-sm btn-danger">
                                    <i class="fas fa-trash-alt"></i> 删除
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <div class="edit-form" id="prov-edit-form" style="display:none">
                <h3><i class="fas fa-edit"></i> 编辑地区运费</h3>
                <form method="post" class="form-group">
                    <input type="hidden" name="act" value="prov_edit">
                    <input type="hidden" name="tab" value="shipping">
                    <input type="hidden" name="admin_pwd" value="admin123">
                    <input type="hidden" name="k" id="prov-key">
                    <div class="form-row">
                        <input type="text" name="new_k" id="prov-new-k" placeholder="地区名称" required>
                        <input type="number" step="0.01" name="v" id="prov-value" placeholder="单价" required>
                        <button type="submit" class="btn-success"><i class="fas fa-save"></i> 保存</button>
                        <button type="button" class="btn-danger" onclick="hideEditForm('prov-edit-form')"><i class="fas fa-times"></i> 取消</button>
                    </div>
                </form>
            </div>
            
            <h3><i class="fas fa-plus-circle"></i> 添加新地区运费</h3>
            <form method="post" class="form-group">
                <input type="hidden" name="act" value="prov_add">
                <input type="hidden" name="tab" value="shipping">
                <input type="hidden" name="admin_pwd" value="admin123">
                <div class="form-row">
                    <input type="text" name="k" placeholder="地区名称" required>
                    <input type="number" step="0.01" name="v" placeholder="单价" required>
                    <button type="submit" class="btn-success"><i class="fas fa-plus"></i> 添加地区</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- 镀锌钢参数 -->
    <div class="tab-content <?php echo $current_tab == 'galvanized' ? 'active' : ''; ?>" id="galvanized">
        <!-- 厚度密度 -->
        <div class="card">
            <div class="card-title">
                <span><i class="fas fa-ruler"></i> 镀锌钢·厚度密度设置</span>
                <span class="badge">kg/㎡</span>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>厚度(mm)</th>
                        <th>kg/㎡</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($cfg['galvanized']['thickness_density'] as $k=>$v): ?>
                    <tr>
                        <td><?php echo $k; ?></td>
                        <td><?php echo $v; ?></td>
                        <td class="action-cell">
                            <button class="btn-sm btn-edit" onclick="showEditForm('gx_t', '<?php echo htmlspecialchars($k); ?>', '<?php echo $v; ?>')">
                                <i class="fas fa-edit"></i> 编辑
                            </button>
                            <form method="post" style="display:inline">
                                <input type="hidden" name="act" value="gx_t_del">
                                <input type="hidden" name="k" value="<?php echo htmlspecialchars($k); ?>">
                                <input type="hidden" name="admin_pwd" value="admin123">
                                <input type="hidden" name="tab" value="galvanized">
                                <button type="submit" class="btn-sm btn-danger">
                                    <i class="fas fa-trash-alt"></i> 删除
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <div class="edit-form" id="gx_t-edit-form" style="display:none">
                <h3><i class="fas fa-edit"></i> 编辑厚度密度</h3>
                <form method="post" class="form-group">
                    <input type="hidden" name="act" value="gx_t_edit">
                    <input type="hidden" name="tab" value="galvanized">
                    <input type="hidden" name="admin_pwd" value="admin123">
                    <input type="hidden" name="k" id="gx_t-key">
                    <div class="form-row">
                        <input type="text" name="new_k" id="gx_t-new-k" placeholder="厚度(mm)" required>
                        <input type="number" step="0.01" name="v" id="gx_t-value" placeholder="kg/㎡" required>
                        <button type="submit" class="btn-success"><i class="fas fa-save"></i> 保存</button>
                        <button type="button" class="btn-danger" onclick="hideEditForm('gx_t-edit-form')"><i class="fas fa-times"></i> 取消</button>
                    </div>
                </form>
            </div>
            
            <h3><i class="fas fa-plus-circle"></i> 添加新厚度</h3>
            <form method="post" class="form-group">
                <input type="hidden" name="act" value="gx_t_add">
                <input type="hidden" name="tab" value="galvanized">
                <input type="hidden" name="admin_pwd" value="admin123">
                <div class="form-row">
                    <input type="text" name="k" placeholder="厚度(mm)" required>
                    <input type="number" step="0.01" name="v" placeholder="kg/㎡" required>
                    <button type="submit" class="btn-success"><i class="fas fa-plus"></i> 添加厚度</button>
                </div>
            </form>
        </div>
        
        <!-- 烤漆单价 -->
        <div class="card">
            <div class="card-title">
                <span><i class="fas fa-paint-roller"></i> 镀锌钢·烤漆单价设置</span>
                <span class="badge">元/kg</span>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>名称</th>
                        <th>元/kg</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($cfg['galvanized']['paint_rates_per_kg'] as $k=>$v): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($k); ?></td>
                        <td><?php echo $v; ?></td>
                        <td class="action-cell">
                            <button class="btn-sm btn-edit" onclick="showEditForm('gx_p', '<?php echo htmlspecialchars($k); ?>', '<?php echo $v; ?>')">
                                <i class="fas fa-edit"></i> 编辑
                            </button>
                            <form method="post" style="display:inline">
                                <input type="hidden" name="act" value="gx_p_del">
                                <input type="hidden" name="k" value="<?php echo htmlspecialchars($k); ?>">
                                <input type="hidden" name="admin_pwd" value="admin123">
                                <input type="hidden" name="tab" value="galvanized">
                                <button type="submit" class="btn-sm btn-danger">
                                    <i class="fas fa-trash-alt"></i> 删除
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <div class="edit-form" id="gx_p-edit-form" style="display:none">
                <h3><i class="fas fa-edit"></i> 编辑烤漆单价</h3>
                <form method="post" class="form-group">
                    <input type="hidden" name="act" value="gx_p_edit">
                    <input type="hidden" name="tab" value="galvanized">
                    <input type="hidden" name="admin_pwd" value="admin123">
                    <input type="hidden" name="k" id="gx_p-key">
                    <div class="form-row">
                        <input type="text" name="new_k" id="gx_p-new-k" placeholder="烤漆名称" required>
                        <input type="number" step="0.01" name="v" id="gx_p-value" placeholder="元/kg" required>
                        <button type="submit" class="btn-success"><i class="fas fa-save"></i> 保存</button>
                        <button type="button" class="btn-danger" onclick="hideEditForm('gx_p-edit-form')"><i class="fas fa-times"></i> 取消</button>
                    </div>
                </form>
            </div>
            
            <h3><i class="fas fa-plus-circle"></i> 添加新烤漆</h3>
            <form method="post" class="form-group">
                <input type="hidden" name="act" value="gx_p_add">
                <input type="hidden" name="tab" value="galvanized">
                <input type="hidden" name="admin_pwd" value="admin123">
                <div class="form-row">
                    <input type="text" name="k" placeholder="烤漆名称" required>
                    <input type="number" step="0.01" name="v" placeholder="元/kg" required>
                    <button type="submit" class="btn-success"><i class="fas fa-plus"></i> 添加烤漆</button>
                </div>
            </form>
        </div>
        
        <!-- 款式溢价 -->
        <div class="card">
            <div class="card-title">
                <span><i class="fas fa-crown"></i> 镀锌钢·款式溢价设置</span>
                <span class="badge">元/kg</span>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>款式</th>
                        <th>元/kg</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($cfg['galvanized']['style_surcharge_per_kg'] as $k=>$v): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($k); ?></td>
                        <td><?php echo $v; ?></td>
                        <td class="action-cell">
                            <button class="btn-sm btn-edit" onclick="showEditForm('gx_s', '<?php echo htmlspecialchars($k); ?>', '<?php echo $v; ?>')">
                                <i class="fas fa-edit"></i> 编辑
                            </button>
                            <form method="post" style="display:inline">
                                <input type="hidden" name="act" value="gx_s_del">
                                <input type="hidden" name="k" value="<?php echo htmlspecialchars($k); ?>">
                                <input type="hidden" name="admin_pwd" value="admin123">
                                <input type="hidden" name="tab" value="galvanized">
                                <button type="submit" class="btn-sm btn-danger">
                                    <i class="fas fa-trash-alt"></i> 删除
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <div class="edit-form" id="gx_s-edit-form" style="display:none">
                <h3><i class="fas fa-edit"></i> 编辑款式溢价</h3>
                <form method="post" class="form-group">
                    <input type="hidden" name="act" value="gx_s_edit">
                    <input type="hidden" name="tab" value="galvanized">
                    <input type="hidden" name="admin_pwd" value="admin123">
                    <input type="hidden" name="k" id="gx_s-key">
                    <div class="form-row">
                        <input type="text" name="new_k" id="gx_s-new-k" placeholder="款式名称" required>
                        <input type="number" step="0.01" name="v" id="gx_s-value" placeholder="元/kg" required>
                        <button type="submit" class="btn-success"><i class="fas fa-save"></i> 保存</button>
                        <button type="button" class="btn-danger" onclick="hideEditForm('gx_s-edit-form')"><i class="fas fa-times"></i> 取消</button>
                    </div>
                </form>
            </div>
            
            <h3><i class="fas fa-plus-circle"></i> 添加新款式</h3>
            <form method="post" class="form-group">
                <input type="hidden" name="act" value="gx_s_add">
                <input type="hidden" name="tab" value="galvanized">
                <input type="hidden" name="admin_pwd" value="admin123">
                <div class="form-row">
                    <input type="text" name="k" placeholder="款式名称" required>
                    <input type="number" step="0.01" name="v" placeholder="元/kg" required>
                    <button type="submit" class="btn-success"><i class="fas fa-plus"></i> 添加款式</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- 不锈钢参数 -->
    <div class="tab-content <?php echo $current_tab == 'stainless' ? 'active' : ''; ?>" id="stainless">
        <!-- 材质/厚度 -->
        <div class="card">
            <div class="card-title">
                <span><i class="fas fa-layer-group"></i> 不锈钢·材质/厚度设置</span>
            </div>
            
            <?php foreach($cfg['stainless']['grades'] as $g=>$rows): ?>
            <div class="section-title" id="grade_<?php echo md5($g); ?>">
                <span><?php echo htmlspecialchars($g); ?></span>
                <form method="post" style="display:inline">
                    <input type="hidden" name="act" value="ss_grade_del">
                    <input type="hidden" name="g" value="<?php echo htmlspecialchars($g); ?>">
                    <input type="hidden" name="admin_pwd" value="admin123">
                    <input type="hidden" name="tab" value="stainless">
                    <button type="submit" class="btn-sm btn-danger">
                        <i class="fas fa-trash-alt"></i> 删除材质
                    </button>
                </form>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>厚度(mm)</th>
                        <th>价/㎡</th>
                        <th>重量/㎡</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($rows as $t=>$rw): ?>
                    <tr>
                        <td><?php echo $t; ?></td>
                        <td><?php echo $rw['price_per_m2']; ?></td>
                        <td><?php echo $rw['weight_per_m2']; ?></td>
                        <td class="action-cell">
                            <button class="btn-sm btn-edit" onclick="showSsEditForm('<?php echo htmlspecialchars($g); ?>', '<?php echo htmlspecialchars($t); ?>', '<?php echo $rw['price_per_m2']; ?>', '<?php echo $rw['weight_per_m2']; ?>')">
                                <i class="fas fa-edit"></i> 编辑
                            </button>
                            <form method="post" style="display:inline">
                                <input type="hidden" name="act" value="ss_t_del">
                                <input type="hidden" name="g" value="<?php echo htmlspecialchars($g); ?>">
                                <input type="hidden" name="t" value="<?php echo htmlspecialchars($t); ?>">
                                <input type="hidden" name="admin_pwd" value="admin123">
                                <input type="hidden" name="tab" value="stainless">
                                <button type="submit" class="btn-sm btn-danger">
                                    <i class="fas fa-trash-alt"></i> 删除
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <div class="edit-form" id="ss_t-edit-form-<?php echo htmlspecialchars($g); ?>" style="display:none">
                <h3><i class="fas fa-edit"></i> 编辑厚度参数</h3>
                <form method="post" class="form-group">
                    <input type="hidden" name="act" value="ss_t_edit">
                    <input type="hidden" name="tab" value="stainless">
                    <input type="hidden" name="admin_pwd" value="admin123">
                    <input type="hidden" name="g" id="ss_g" value="<?php echo htmlspecialchars($g); ?>">
                    <input type="hidden" name="t" id="ss_t">
                    <div class="form-row">
                        <input type="text" name="new_t" id="ss_new_t" placeholder="厚度(mm)" required>
                        <input type="number" step="0.01" name="p" id="ss_p" placeholder="价/㎡" required>
                        <input type="number" step="0.01" name="w" id="ss_w" placeholder="重量/㎡" required>
                        <button type="submit" class="btn-success"><i class="fas fa-save"></i> 保存</button>
                        <button type="button" class="btn-danger" onclick="hideEditForm('ss_t-edit-form-<?php echo htmlspecialchars($g); ?>')"><i class="fas fa-times"></i> 取消</button>
                    </div>
                </form>
            </div>
            
            <h3><i class="fas fa-plus-circle"></i> 添加新厚度</h3>
            <form method="post" class="form-group">
                <input type="hidden" name="act" value="ss_t_add">
                <input type="hidden" name="tab" value="stainless">
                <input type="hidden" name="admin_pwd" value="admin123">
                <input type="hidden" name="g" value="<?php echo htmlspecialchars($g); ?>">
                <div class="form-row">
                    <input type="text" name="t" placeholder="厚度(mm)" required>
                    <input type="number" step="0.01" name="p" placeholder="价/㎡" required>
                    <input type="number" step="0.01" name="w" placeholder="重量/㎡" required>
                    <button type="submit" class="btn-success"><i class="fas fa-plus"></i> 添加厚度</button>
                </div>
            </form>
            <?php endforeach; ?>
            
            <h3><i class="fas fa-plus-circle"></i> 创建新材质</h3>
            <form method="post" class="form-group">
                <input type="hidden" name="act" value="ss_grade_add">
                <input type="hidden" name="tab" value="stainless">
                <input type="hidden" name="admin_pwd" value="admin123">
                <div class="form-row">
                    <input type="text" name="g" placeholder="新材质名称" required>
                    <button type="submit" class="btn"><i class="fas fa-plus"></i> 创建新材质</button>
                </div>
            </form>
        </div>
        
        <!-- 烤漆设置 -->
        <div class="card">
            <div class="card-title">
                <span><i class="fas fa-paint-roller"></i> 不锈钢·烤漆设置</span>
                <span class="badge">元/kg</span>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>名称</th>
                        <th>元/kg</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($cfg['stainless']['paint_rates_per_kg'] as $k=>$v): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($k); ?></td>
                        <td><?php echo $v; ?></td>
                        <td class="action-cell">
                            <button class="btn-sm btn-edit" onclick="showEditForm('ss_p', '<?php echo htmlspecialchars($k); ?>', '<?php echo $v; ?>')">
                                <i class="fas fa-edit"></i> 编辑
                            </button>
                            <form method="post" style="display:inline">
                                <input type="hidden" name="act" value="ss_p_del">
                                <input type="hidden" name="k" value="<?php echo htmlspecialchars($k); ?>">
                                <input type="hidden" name="admin_pwd" value="admin123">
                                <input type="hidden" name="tab" value="stainless">
                                <button type="submit" class="btn-sm btn-danger">
                                    <i class="fas fa-trash-alt"></i> 删除
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <div class="edit-form" id="ss_p-edit-form" style="display:none">
                <h3><i class="fas fa-edit"></i> 编辑烤漆设置</h3>
                <form method="post" class="form-group">
                    <input type="hidden" name="act" value="ss_p_edit">
                    <input type="hidden" name="tab" value="stainless">
                    <input type="hidden" name="admin_pwd" value="admin123">
                    <input type="hidden" name="k" id="ss_p-key">
                    <div class="form-row">
                        <input type="text" name="new_k" id="ss_p-new-k" placeholder="烤漆名称" required>
                        <input type="number" step="0.01" name="v" id="ss_p-value" placeholder="元/kg" required>
                        <button type="submit" class="btn-success"><i class="fas fa-save"></i> 保存</button>
                        <button type="button" class="btn-danger" onclick="hideEditForm('ss_p-edit-form')"><i class="fas fa-times"></i> 取消</button>
                    </div>
                </form>
            </div>
            
            <h3><i class="fas fa-plus-circle"></i> 添加新烤漆</h3>
            <form method="post" class="form-group">
                <input type="hidden" name="act" value="ss_p_add">
                <input type="hidden" name="tab" value="stainless">
                <input type="hidden" name="admin_pwd" value="admin123">
                <div class="form-row">
                    <input type="text" name="k" placeholder="烤漆名称" required>
                    <input type="number" step="0.01" name="v" placeholder="元/kg" required>
                    <button type="submit" class="btn-success"><i class="fas fa-plus"></i> 添加烤漆</button>
                </div>
            </form>
        </div>
        
        <!-- 非烤漆设置 -->
        <div class="card">
            <div class="card-title">
                <span><i class="fas fa-square"></i> 不锈钢·非烤漆设置</span>
                <span class="badge">元/㎡</span>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>名称</th>
                        <th>元/㎡</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($cfg['stainless']['non_paint_per_m2'] as $k=>$v): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($k); ?></td>
                        <td><?php echo $v; ?></td>
                        <td class="action-cell">
                            <button class="btn-sm btn-edit" onclick="showEditForm('ss_np', '<?php echo htmlspecialchars($k); ?>', '<?php echo $v; ?>')">
                                <i class="fas fa-edit"></i> 编辑
                            </button>
                            <form method="post" style="display:inline">
                                <input type="hidden" name="act" value="ss_np_del">
                                <input type="hidden" name="k" value="<?php echo htmlspecialchars($k); ?>">
                                <input type="hidden" name="admin_pwd" value="admin123">
                                <input type="hidden" name="tab" value="stainless">
                                <button type="submit" class="btn-sm btn-danger">
                                    <i class="fas fa-trash-alt"></i> 删除
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <div class="edit-form" id="ss_np-edit-form" style="display:none">
                <h3><i class="fas fa-edit"></i> 编辑非烤漆设置</h3>
                <form method="post" class="form-group">
                    <input type="hidden" name="act" value="ss_np_edit">
                    <input type="hidden" name="tab" value="stainless">
                    <input type="hidden" name="admin_pwd" value="admin123">
                    <input type="hidden" name="k" id="ss_np-key">
                    <div class="form-row">
                        <input type="text" name="new_k" id="ss_np-new-k" placeholder="处理名称" required>
                        <input type="number" step="0.01" name="v" id="ss_np-value" placeholder="元/㎡" required>
                        <button type="submit" class="btn-success"><i class="fas fa-save"></i> 保存</button>
                        <button type="button" class="btn-danger" onclick="hideEditForm('ss_np-edit-form')"><i class="fas fa-times"></i> 取消</button>
                    </div>
                </form>
            </div>
            
            <h3><i class="fas fa-plus-circle"></i> 添加新处理方式</h3>
            <form method="post" class="form-group">
                <input type="hidden" name="act" value="ss_np_add">
                <input type="hidden" name="tab" value="stainless">
                <input type="hidden" name="admin_pwd" value="admin123">
                <div class="form-row">
                    <input type="text" name="k" placeholder="处理名称" required>
                    <input type="number" step="0.01" name="v" placeholder="元/㎡" required>
                    <button type="submit" class="btn-success"><i class="fas fa-plus"></i> 添加处理方式</button>
                </div>
            </form>
        </div>
        
        <!-- 款式溢价 -->
        <div class="card">
            <div class="card-title">
                <span><i class="fas fa-crown"></i> 不锈钢·款式溢价设置</span>
                <span class="badge">元/kg</span>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>款式</th>
                        <th>元/kg</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($cfg['stainless']['style_surcharge_per_kg'] as $k=>$v): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($k); ?></td>
                        <td><?php echo $v; ?></td>
                        <td class="action-cell">
                            <button class="btn-sm btn-edit" onclick="showEditForm('ss_s', '<?php echo htmlspecialchars($k); ?>', '<?php echo $v; ?>')">
                                <i class="fas fa-edit"></i> 编辑
                            </button>
                            <form method="post" style="display:inline">
                                <input type="hidden" name="act" value="ss_s_del">
                                <input type="hidden" name="k" value="<?php echo htmlspecialchars($k); ?>">
                                <input type="hidden" name="admin_pwd" value="admin123">
                                <input type="hidden" name="tab" value="stainless">
                                <button type="submit" class="btn-sm btn-danger">
                                    <i class="fas fa-trash-alt"></i> 删除
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <div class="edit-form" id="ss_s-edit-form" style="display:none">
                <h3><i class="fas fa-edit"></i> 编辑款式溢价</h3>
                <form method="post" class="form-group">
                    <input type="hidden" name="act" value="ss_s_edit">
                    <input type="hidden" name="tab" value="stainless">
                    <input type="hidden" name="admin_pwd" value="admin123">
                    <input type="hidden" name="k" id="ss_s-key">
                    <div class="form-row">
                        <input type="text" name="new_k" id="ss_s-new-k" placeholder="款式名称" required>
                        <input type="number" step="0.01" name="v" id="ss_s-value" placeholder="元/kg" required>
                        <button type="submit" class="btn-success"><i class="fas fa-save"></i> 保存</button>
                        <button type="button" class="btn-danger" onclick="hideEditForm('ss_s-edit-form')"><i class="fas fa-times"></i> 取消</button>
                    </div>
                </form>
            </div>
            
            <h3><i class="fas fa-plus-circle"></i> 添加新款式</h3>
            <form method="post" class="form-group">
                <input type="hidden" name="act" value="ss_s_add">
                <input type="hidden" name="tab" value="stainless">
                <input type="hidden" name="admin_pwd" value="admin123">
                <div class="form-row">
                    <input type="text" name="k" placeholder="款式名称" required>
                    <input type="number" step="0.01" name="v" placeholder="元/kg" required>
                    <button type="submit" class="btn-success"><i class="fas fa-plus"></i> 添加款式</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- 利润率设置 -->
    <div class="tab-content <?php echo $current_tab == 'profit' ? 'active' : ''; ?>" id="profit">
        <div class="card">
            <div class="card-title">
                <span><i class="fas fa-chart-line"></i> 利润率设置</span>
            </div>
            
            <div class="notice">
                <p><strong>说明：</strong>输入小数形式，例如：0.20 表示 20%</p>
            </div>
            
            <div class="warning">
                <p><strong>当前设置：</strong><?php echo implode('，', array_map(fn($x)=>($x*100).'%', $cfg['ui']['profit_rates'])); ?></p>
            </div>
            
            <div class="grid">
                <div>
                    <form method="post" class="form-group">
                        <input type="hidden" name="act" value="profit_add">
                        <input type="hidden" name="tab" value="profit">
                        <input type="hidden" name="admin_pwd" value="admin123">
                        <label>添加新利润率</label>
                        <div class="form-row">
                            <input type="number" step="0.01" name="v" placeholder="利润率" required>
                            <button type="submit" class="btn-success"><i class="fas fa-plus"></i> 添加</button>
                        </div>
                    </form>
                </div>
                
                <div>
                    <form method="post" class="form-group">
                        <input type="hidden" name="act" value="profit_del">
                        <input type="hidden" name="tab" value="profit">
                        <input type="hidden" name="admin_pwd" value="admin123">
                        <label>删除利润率</label>
                        <div class="form-row">
                            <input type="number" step="0.01" name="v" placeholder="利润率" required>
                            <button type="submit" class="btn-danger"><i class="fas fa-minus"></i> 删除</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// 标签页切换功能
document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
        const tabId = tab.getAttribute('data-tab');
        // 移除所有标签的active类
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        
        // 添加当前标签的active类
        tab.classList.add('active');
        document.getElementById(tabId).classList.add('active');
    });
});

// 显示编辑表单
function showEditForm(type, key, value) {
    const form = document.getElementById(`${type}-edit-form`);
    document.getElementById(`${type}-key`).value = key;
    document.getElementById(`${type}-new-k`).value = key;
    document.getElementById(`${type}-value`).value = value;
    form.style.display = 'block';
    
    // 滚动到编辑表单
    form.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// 显示不锈钢厚度编辑表单
function showSsEditForm(g, t, p, w) {
    const form = document.getElementById(`ss_t-edit-form-${g}`);
    document.getElementById('ss_g').value = g;
    document.getElementById('ss_t').value = t;
    document.getElementById('ss_new_t').value = t;
    document.getElementById('ss_p').value = p;
    document.getElementById('ss_w').value = w;
    form.style.display = 'block';
    
    // 滚动到编辑表单
    form.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// 隐藏编辑表单
function hideEditForm(formId) {
    document.getElementById(formId).style.display = 'none';
}

// 页面加载后滚动到指定位置
document.addEventListener('DOMContentLoaded', function() {
    const scrollTo = '<?php echo $scroll_to; ?>';
    if (scrollTo) {
        const element = document.getElementById(scrollTo);
        if (element) {
            setTimeout(() => {
                element.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 300);
        }
    }
});
</script>
</body>
</html>