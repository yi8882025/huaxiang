
<?php session_start(); ?>
<!doctype html><html lang="zh"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>管理员登录</title>
<style>
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,PingFang SC,Microsoft Yahei, sans-serif;height:100vh;display:grid;place-items:center;background:linear-gradient(135deg,#e0e7ff,#f0f9ff)}
.card{background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:24px;min-width:340px;box-shadow:0 10px 24px rgba(2,6,23,.12)}
h3{margin:0 0 12px}
input{width:100%;padding:12px;border:1px solid #cbd5e1;border-radius:10px;margin:6px 0}
button{width:100%;padding:12px;border:0;border-radius:10px;background:linear-gradient(90deg,#2563eb,#60a5fa);color:#fff;font-weight:700}
</style></head><body>
<div class="card">
<h3>管理员登录</h3>
<form method="post" action="/api/login.php">
  <input name="username" placeholder="用户名(管理员)" required>
  <input name="password" type="password" placeholder="密码" required>
  <button>登录</button>
</form>
</div>
</body></html>
