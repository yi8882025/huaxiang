<?php
require_once __DIR__.'/../api/_auth.php'; require_admin();
$usersPath = __DIR__.'/../data/users.json';
$users = json_decode(file_get_contents($usersPath), true) ?: [];

$action = $_POST['action'] ?? '';
if($action==='add'){
  $name=trim($_POST['name']??''); $pass=$_POST['pass']??'';
  if($name && $pass){
    $users[$name] = ['role'=>'sub','password_hash'=>hash('sha256',$pass)];
    file_put_contents($usersPath, json_encode($users,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
  }
}elseif($action==='del'){
  $name=$_POST['name']??''; if($name && isset($users[$name]) && $name!=='admin'){ unset($users[$name]); file_put_contents($usersPath, json_encode($users,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)); }
}elseif($action==='reset'){
  $name=$_POST['name']??''; $pass=$_POST['pass']??'';
  if($name && isset($users[$name]) && $pass){
    $users[$name]['password_hash']=hash('sha256',$pass);
    file_put_contents($usersPath, json_encode($users,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
  }
}
?><!doctype html><html lang="zh"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>子账号管理</title>

    body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,PingFang SC,Microsoft Yahei, sans-serif;margin:0;color:#0f172a;background:#f9fafb}
    .header{background:linear-gradient(90deg,#2563eb,#60a5fa);color:#fff;padding:16px 20px;font-weight:800;}
    .wrap{max-width:1100px;margin:22px auto;padding:0 18px}
    .card{background:#fff;border:1px solid #e5e7eb;border-radius:18px;padding:18px;box-shadow:0 12px 28px rgba(2,6,23,.08);margin-bottom:18px}
    .table{width:100%;border-collapse:collapse}
    .table th,.table td{padding:12px 16px;border:1px solid #e5e7eb;text-align:center;font-size:14px}
    .btn{background:linear-gradient(90deg,#2563eb,#60a5fa);color:#fff;padding:10px 12px;border-radius:12px;text-decoration:none}
    .btn:hover{filter:brightness(1.05)}
    .input{padding:12px 16px;border-radius:12px;width:100%;border:1px solid #cbd5e1;font-size:14px}
    
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,PingFang SC,Microsoft Yahei, sans-serif;margin:0;background:#f6f7fb;color:#0f172a}
.header{background:linear-gradient(90deg,#2563eb,#60a5fa);color:#fff;padding:14px 18px;font-weight:700;box-shadow:0 6px 16px rgba(37,99,235,.25)}
.wrap{max-width:1200px;margin:20px auto;padding:0 18px}
.card{background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:16px;box-shadow:0 10px 26px rgba(2,6,23,.06);margin-bottom:16px}
.btn{display:inline-block;background:linear-gradient(90deg,#2563eb,#60a5fa);color:#fff;border:0;border-radius:10px;padding:10px 14px;text-decoration:none}
.btn:hover{filter:brightness(1.05)}
table{border-collapse:separate;border-spacing:0;width:100%;overflow:hidden;border-radius:12px}
th{background:#f1f5f9}
td,th{border:1px solid #e5e7eb;padding:8px 10px;text-align:left}
input,select{padding:10px;border:1px solid #cbd5e1;border-radius:10px}
button{padding:10px 12px;border-radius:10px;border:0;background:#2563eb;color:#fff}
button:hover{filter:brightness(1.05)}
a.link{color:#2563eb;text-decoration:none}
a.link:hover{text-decoration:underline}
.notice{margin:8px 0;padding:10px 12px;border-left:4px solid #10b981;background:#ecfdf5}
.err{margin:8px 0;padding:10px 12px;border-left:4px solid #ef4444;background:#fef2f2}

body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,PingFang SC,Microsoft Yahei, sans-serif;max-width:900px;margin:24px auto;padding:0 16px}
table{border-collapse:collapse;width:100%} td,th{border:1px solid #e5e7eb;padding:8px}
input,button{padding:8px;margin:4px}
</style></head><body>
<h2>子账号管理</h2>
<p><a href="/admin/">返回后台首页</a>　|　<a href="/api/logout.php">退出登录</a></p>
<h3>添加子账号</h3>
<form method="post">
  <input type="hidden" name="action" value="add">
  用户名：<input name="name" required>　密码：<input name="pass" required>
  <button>添加</button>
</form>
<h3>子账号列表</h3>
<table><thead><tr><th>用户名</th><th>角色</th><th>操作</th></tr></thead><tbody>
<?php foreach($users as $name=>$info): ?>
  <tr>
    <td><?php echo htmlspecialchars($name); ?></td>
    <td><?php echo htmlspecialchars($info['role']); ?></td>
    <td>
      <?php if($name!=='admin'): ?>
      <form method="post" style="display:inline">
        <input type="hidden" name="action" value="del"><input type="hidden" name="name" value="<?php echo htmlspecialchars($name); ?>">
        <button onclick="return confirm('删除该子账号？')">删除</button>
      </form>
      <form method="post" style="display:inline">
        <input type="hidden" name="action" value="reset"><input type="hidden" name="name" value="<?php echo htmlspecialchars($name); ?>">
        新密码：<input name="pass" required>
        <button>重置密码</button>
      </form>
      <?php else: ?>—<?php endif; ?>
    </td>
  </tr>
<?php endforeach; ?>
</tbody></table>
</body></html>
