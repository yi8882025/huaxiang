
<?php
session_start();
$err = isset($_GET['err']);
?><!doctype html><html lang="zh"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>登录 · 花箱报价</title>
<style>
:root{--c1:#0ea5e9;--c2:#a78bfa;--c3:#22d3ee;--dark:#0b1220}
*{box-sizing:border-box} html,body{height:100%}
body{
  margin:0;display:grid;place-items:center;background:radial-gradient(1200px 600px at 10% 0%, rgba(34,211,238,.25), transparent 60%),
  radial-gradient(1000px 500px at 90% 100%, rgba(167,139,250,.3), transparent 60%), #0f172a;
  color:#e5e7eb; overflow:hidden;
}
.blob{position:absolute;filter:blur(60px);opacity:.6;animation:float 12s ease-in-out infinite alternate}
.blob1{top:-10vh;left:-10vw;width:50vw;height:50vh;background:conic-gradient(from 180deg at 50% 50%, var(--c1), var(--c2), var(--c3), var(--c1))}
.blob2{bottom:-10vh;right:-10vw;width:45vw;height:45vh;background:conic-gradient(from 0deg at 50% 50%, var(--c2), var(--c3), var(--c1), var(--c2)); animation-duration:14s}
@keyframes float{to{transform:translateY(20px) translateX(10px) rotate(10deg)}}
.card{
  position:relative; z-index:2; width:min(92vw,420px);
  background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.15);
  border-radius:18px; padding:28px; backdrop-filter: blur(14px) saturate(1.2);
  box-shadow:0 20px 60px rgba(2,6,23,.45);
}
h1{margin:0 0 6px;font-size:22px;font-weight:800;letter-spacing:.3px}
p.sub{margin:0 0 22px;color:#cbd5e1}
label{display:block;margin-top:10px;margin-bottom:6px;color:#e2e8f0;font-size:14px}
input{
  width:100%; padding:12px 14px; border-radius:12px;
  background:rgba(255,255,255,.9); border:2px solid transparent; outline:none;
  transition:border-color .2s ease;
}
input:focus{border-color:#38bdf8}
button{
  width:100%; margin-top:14px; padding:12px 14px; border-radius:12px; border:0; cursor:pointer;
  color:#0b1220; font-weight:700; background:linear-gradient(90deg,#22d3ee,#a78bfa);
  box-shadow:0 10px 24px rgba(34,211,238,.25);
}
.err{color:#fecaca;margin:8px 0 0}
.footer{margin-top:14px;display:flex;justify-content:space-between;color:#94a3b8;font-size:12px}
a.link{color:#e2e8f0;text-decoration:none;opacity:.9}
a.link:hover{opacity:1}
</style></head><body>
<div class="blob blob1"></div><div class="blob blob2"></div>
<div class="card">
  <h1>登录使用</h1>
  <p class="sub">请输入子账号或管理员账号后进入系统</p>
  <?php if($err): ?><div class="err">账号或密码错误</div><?php endif; ?>
  <form method="post" action="/api/login.php">
    <label>账号</label>
    <input name="username" placeholder="子账号/管理员" required>
    <label>密码</label>
    <input name="password" type="password" placeholder="密码" required>
    <button>进入</button>
  </form>
  <div class="footer">
    <span>© 花箱报价</span>
    <a class="link" href="#" onclick="alert('如需开通子账号，请联系管理员。');return false;">需要开通？</a>
  </div>
</div>
</body></html>
