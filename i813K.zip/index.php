<?php
require_once __DIR__.'/api/_auth.php'; require_sub(); // 需要子账号或管理员登录
?><!doctype html><html lang="zh"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>花箱报价计算器（镀锌钢 & 不锈钢）</title>
<link rel="stylesheet" href="/assets/style.css">
</head><body>
<header class="navbar">花箱报价计算器（镀锌钢 & 不锈钢）　<a class="navlink" href="/api/logout.php">退出</a></header>
<main class="container">
  <section class="dims">
    <h3>通用尺寸（数量固定为 1）</h3>
    <div class="grid3">
      <div><label>长(cm)</label><input id="L" class="hl" type="number" value="100"></div>
      <div><label>宽(cm)</label><input id="W" class="hl" type="number" value="20"></div>
      <div><label>高(cm)</label><input id="H" class="hl" type="number" value="60"></div>
    </div>
    <button id="calc_btn" style="margin-top:15px">计算所有报价</button>
    <div id="cfgStatus" class="tip">正在载入参数...</div>
  </section>

  <section class="two-cols">
    <article class="card">
      <h3>镀锌钢</h3>
      <label>厚度(mm)</label><select id="gx_t"></select>
      <label>烤漆类型（元/kg）</label><select id="gx_paint"></select>
      <label>款式（元/kg 溢价）</label><select id="gx_style"></select>
      <label>地区（运费）</label><select id="gx_prov"></select>
      <label>其他成本（元）</label><input id="gx_other" type="number" value="0">
      <label>包装成本（元）</label><input id="gx_pack" type="number" value="0">
      <div class="result" id="gx_out"></div>
      <table class="tbl" id="gx_tbl">
        <thead><tr><th>利润率(%)</th><th>数量</th><th>单价(元)</th><th>总价(元)</th><th>运费(元)</th><th>含运费总价(元)</th></tr></thead>
        <tbody></tbody>
      </table>
    </article>

    <article class="card">
      <h3>不锈钢</h3>
      <label>材质</label><select id="ss_grade"></select>
      <label>厚度(mm)</label><select id="ss_t"></select>
      <label>款式（元/kg 溢价）</label><select id="ss_style"></select>

      <div class="rowradio">
        <label><input id="ss_r_paint" type="radio" name="ss_proc" value="paint"> 烤漆（元/kg）</label>
        <label><input id="ss_r_non" type="radio" name="ss_proc" value="non" checked> 非烤漆（元/㎡）</label>
      </div>
      <div id="ss_box_paint" style="display:none"><label>油漆类型（元/kg）</label><select id="ss_paint"></select></div>
      <div id="ss_box_non"><label>非烤漆类型（元/㎡）</label><select id="ss_non"></select></div>

      <label>地区（运费）</label><select id="ss_prov"></select>
      <label>其他成本（元）</label><input id="ss_other" type="number" value="0">
      <label>包装成本（元）</label><input id="ss_pack" type="number" value="0">
      <div class="result" id="ss_out"></div>
      <table class="tbl" id="ss_tbl">
        <thead><tr><th>利润率(%)</th><th>数量</th><th>单价(元)</th><th>总价(元)</th><th>运费(元)</th><th>含运费总价(元)</th></tr></thead>
        <tbody></tbody>
      </table>
    </article>
  </section>
</main>
<script>
// 定义全局计算函数（作为后备方案）
window.calcGalvanized = function() {
  console.log("基础镀锌钢计算函数被调用");
  const resultDiv = document.getElementById('gx_out');
  resultDiv.textContent = '镀锌钢计算功能未实现 - 请检查 app.js 加载';
};

window.calcStainless = function() {
  console.log("基础不锈钢计算函数被调用");
  const resultDiv = document.getElementById('ss_out');
  resultDiv.textContent = '不锈钢计算功能未实现 - 请检查 app.js 加载';
};

// 修复Infinity问题
function fixInfinity() {
  document.querySelectorAll('.result, .tbl').forEach(el => {
    el.innerHTML = el.innerHTML.replace(/Infinity/g, '无效值');
  });
}
</script>
<script src="/assets/app.js"></script>
<script>
// 确保在页面加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
  const calcBtn = document.getElementById('calc_btn');
  const cfgStatus = document.getElementById('cfgStatus');
  
  // 计算所有报价
  function calculateAll() {
    try {
      console.log("尝试计算...");
      
      // 检查计算函数是否可用
      if (typeof window.calcGalvanized === 'function') {
        console.log("调用 calcGalvanized");
        window.calcGalvanized();
      } else {
        console.error('calcGalvanized 函数未定义');
        cfgStatus.textContent = '错误：calcGalvanized 函数未定义 - 请检查 app.js 加载';
      }
      
      if (typeof window.calcStainless === 'function') {
        console.log("调用 calcStainless");
        window.calcStainless();
      } else {
        console.error('calcStainless 函数未定义');
        cfgStatus.textContent = '错误：calcStainless 函数未定义 - 请检查 app.js 加载';
      }
      
      fixInfinity();
    } catch (error) {
      console.error('计算错误:', error);
      cfgStatus.textContent = '计算错误: ' + error.message;
    }
  }
  
  // 绑定计算按钮事件
  calcBtn.addEventListener('click', calculateAll);
  
  // 输入框变化时自动计算
  const inputs = document.querySelectorAll('input, select');
  inputs.forEach(input => {
    input.addEventListener('change', calculateAll);
  });
  
  // 不锈钢处理方式切换
  document.querySelectorAll('input[name="ss_proc"]').forEach(radio => {
    radio.addEventListener('change', function() {
      document.getElementById('ss_box_paint').style.display = 
        this.value === 'paint' ? 'block' : 'none';
      document.getElementById('ss_box_non').style.display = 
        this.value === 'non' ? 'block' : 'none';
      calculateAll();
    });
  });
  
  // 确保所有下拉菜单可用
  function enableAllSelects() {
    const allSelects = document.querySelectorAll('select');
    allSelects.forEach(select => {
      select.disabled = false;
    });
  }
  
  // 初始启用所有下拉菜单
  enableAllSelects();
  
  // 初始计算（延迟执行）
  setTimeout(() => {
    console.log("尝试初始计算...");
    calculateAll();
  }, 1500);
});
</script>
</body></html>